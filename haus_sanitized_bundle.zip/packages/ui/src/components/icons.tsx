import { Check, Copy, Loader2, LogOut } from "lucide-react";

export const Icons = {
  SignOut: LogOut,
  Copy,
  Check,
  Loader: Loader2,
};
