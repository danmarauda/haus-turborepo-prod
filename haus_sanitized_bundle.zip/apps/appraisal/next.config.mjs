/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ["@haus/ui"],
};

export default nextConfig;
