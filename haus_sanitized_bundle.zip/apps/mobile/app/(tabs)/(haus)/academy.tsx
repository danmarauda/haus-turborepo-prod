import { AcademyDashboard } from "@/components/academy";

export default function AcademyScreen() {
  return <AcademyDashboard />;
}
