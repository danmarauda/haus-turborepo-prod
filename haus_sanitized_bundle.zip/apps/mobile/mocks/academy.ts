// Re-export from lib/data/academy for backward compatibility
export * from "@/lib/data/academy";
