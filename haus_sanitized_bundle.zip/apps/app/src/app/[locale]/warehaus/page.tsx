"use client";

import { WAREHAUSContent } from "@/components/warehaus/warehaus-content";

export default function WarehausPage() {
  return <WAREHAUSContent />;
}
