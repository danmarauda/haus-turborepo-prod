import { SearchContent } from "@/components/haus/search-content";

export default function SearchPage() {
  return <SearchContent />;
}
