
import React from 'react';
const Sidebar = () => <div className="hidden">Deprecated</div>;
export default Sidebar;
