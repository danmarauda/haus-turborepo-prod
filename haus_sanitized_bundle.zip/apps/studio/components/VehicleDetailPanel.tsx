
import React from 'react';
const VehicleDetailPanel = () => null;
export default VehicleDetailPanel;
