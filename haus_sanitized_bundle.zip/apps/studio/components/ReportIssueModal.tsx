
import React from 'react';
const ReportIssueModal = () => null;
export default ReportIssueModal;
