
import React from 'react';
const VehicleMarker = () => null;
export default VehicleMarker;
