
import React from 'react';
const MaterialLogistics = () => <div className="hidden">Deprecated</div>;
export default MaterialLogistics;
