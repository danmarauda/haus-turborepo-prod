
import React from 'react';
const ControlPanel = () => <div className="hidden">Deprecated</div>;
export default ControlPanel;
