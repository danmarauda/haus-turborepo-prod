
import React from 'react';
const ActivityFeed = () => <div className="hidden">Deprecated</div>;
export default ActivityFeed;
