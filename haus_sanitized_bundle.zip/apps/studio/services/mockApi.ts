
// This service is deprecated in HAUS SS-Tier.
// Retaining file shell to prevent import errors during transition.

export const fetchProjectStats = async () => null;
export const fetchInTransitMaterials = async () => [];
export const fetchOnSiteMaterials = async () => [];
export const fetchTeamMembers = async () => [];
export const fetchLiveActivities = async () => [];
